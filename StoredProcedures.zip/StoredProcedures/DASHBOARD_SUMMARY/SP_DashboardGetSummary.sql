-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch combined dashboard summary (today's sales, low stock, near-expiry, pending credit)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_DashboardGetSummary
    @storeID INT
AS
BEGIN
    -- Today's sales
    SELECT ISNULL(SUM(TotalAmount), 0) AS TodaySales
    FROM Invoices
    WHERE StoreId = @storeID AND CAST(InvoiceDate AS DATE) = CAST(GETDATE() AS DATE) AND IsActive = 1;

    -- Low stock count
    SELECT COUNT(*) AS LowStockCount
    FROM (
        SELECT m.MedicineId, ISNULL(SUM(b.QuantityRemaining), 0) AS CurrentStock, m.ReorderPoint
        FROM Medicines m
        LEFT JOIN Batches b ON m.MedicineId = b.MedicineId AND b.IsActive = 1
        WHERE m.StoreId = @storeID AND m.IsActive = 1
        GROUP BY m.MedicineId, m.ReorderPoint
        HAVING ISNULL(SUM(b.QuantityRemaining), 0) <= m.ReorderPoint
    ) AS LowStock;

    -- Near expiry count (30 days)
    SELECT COUNT(*) AS NearExpiryCount
    FROM Batches
    WHERE StoreId = @storeID AND IsActive = 1 AND QuantityRemaining > 0
      AND DATEDIFF(DAY, GETDATE(), ExpiryDate) <= 30;

    -- Total pending credit amount
    SELECT ISNULL(SUM(Amount - AmountPaid), 0) AS TotalPendingCredit
    FROM CustomerCredits
    WHERE StoreId = @storeID AND Status IN ('Pending', 'PartiallyPaid');
END
GO
