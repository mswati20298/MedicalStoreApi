-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to deactivate a user account
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UserDeactivate
    @userID INT
AS
BEGIN
    UPDATE Users SET IsActive = 0 WHERE UserId = @userID;
END
GO
