-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch user details by username (used at login)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UserGetByUsername
    @username VARCHAR(100)
AS
BEGIN
    SELECT u.*, r.RoleName
    FROM Users u
    JOIN Roles r ON u.RoleId = r.RoleId
    WHERE u.Username = @username AND u.IsActive = 1;
END
GO
