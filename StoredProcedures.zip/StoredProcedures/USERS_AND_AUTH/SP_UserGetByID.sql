-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch user details by user ID
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UserGetByID
    @userID INT
AS
BEGIN
    SELECT u.*, r.RoleName
    FROM Users u
    JOIN Roles r ON u.RoleId = r.RoleId
    WHERE u.UserId = @userID AND u.IsActive = 1;
END
GO
