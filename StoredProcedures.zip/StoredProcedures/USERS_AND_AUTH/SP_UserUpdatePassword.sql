-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to update a user's password
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UserUpdatePassword
    @userID INT,
    @passwordHash VARCHAR(255)
AS
BEGIN
    UPDATE Users SET PasswordHash = @passwordHash WHERE UserId = @userID;
END
GO
