-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all users of a store
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UserGetByStore
    @storeID INT
AS
BEGIN
    SELECT u.*, r.RoleName
    FROM Users u
    JOIN Roles r ON u.RoleId = r.RoleId
    WHERE u.StoreId = @storeID AND u.IsActive = 1;
END
GO
