-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new user (staff/owner)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UserInsert
    @storeID INT,
    @roleID INT,
    @fullName VARCHAR(150),
    @username VARCHAR(100),
    @passwordHash VARCHAR(255),
    @email VARCHAR(150) = NULL,
    @mobile VARCHAR(15) = NULL
AS
BEGIN
    INSERT INTO Users (StoreId, RoleId, FullName, Username, PasswordHash, Email, Mobile, IsActive)
    VALUES (@storeID, @roleID, @fullName, @username, @passwordHash, @email, @mobile, 1);
    SELECT SCOPE_IDENTITY() AS UserID;
END
GO
