-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch invoice header and items by invoice ID
-- =====================================================
CREATE OR ALTER PROCEDURE SP_InvoiceGetByID
    @invoiceID INT
AS
BEGIN
    SELECT i.*, c.Name AS CustomerName, c.Mobile AS CustomerMobile, pm.ModeName
    FROM Invoices i
    LEFT JOIN Customers c ON i.CustomerId = c.CustomerId
    LEFT JOIN PaymentModes pm ON i.PaymentModeId = pm.PaymentModeId
    WHERE i.InvoiceId = @invoiceID;

    SELECT ii.*, m.Name AS MedicineName, b.BatchNumber, b.ExpiryDate
    FROM InvoiceItems ii
    JOIN Medicines m ON ii.MedicineId = m.MedicineId
    JOIN Batches b ON ii.BatchId = b.BatchId
    WHERE ii.InvoiceId = @invoiceID;
END
GO
