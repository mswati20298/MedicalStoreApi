-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to add an invoice line item and reduce batch stock in one atomic step
-- =====================================================
CREATE OR ALTER PROCEDURE SP_InvoiceItemInsertAndReduceStock
    @invoiceID INT,
    @batchID INT,
    @medicineID INT,
    @quantity INT,
    @unitPrice DECIMAL(10,2),
    @gstPercentage DECIMAL(5,2),
    @gstAmount DECIMAL(10,2),
    @lineTotal DECIMAL(10,2)
AS
BEGIN
    DECLARE @availableQty INT;

    SELECT @availableQty = QuantityRemaining
    FROM Batches WITH (UPDLOCK, ROWLOCK)
    WHERE BatchId = @batchID;

    IF @availableQty >= @quantity
    BEGIN
        INSERT INTO InvoiceItems (
            InvoiceId, BatchId, MedicineId, Quantity, UnitPrice,
            GSTPercentage, GSTAmount, LineTotal
        )
        VALUES (
            @invoiceID, @batchID, @medicineID, @quantity, @unitPrice,
            @gstPercentage, @gstAmount, @lineTotal
        );

        UPDATE Batches
        SET QuantityRemaining = QuantityRemaining - @quantity
        WHERE BatchId = @batchID;

        SELECT 1 AS Success, 'Item added successfully' AS Message;
    END
    ELSE
    BEGIN
        SELECT 0 AS Success, 'Insufficient stock in this batch' AS Message;
    END
END
GO
