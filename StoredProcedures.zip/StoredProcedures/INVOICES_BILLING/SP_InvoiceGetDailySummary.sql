-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch daily sales summary for dashboard
-- =====================================================
CREATE OR ALTER PROCEDURE SP_InvoiceGetDailySummary
    @storeID INT,
    @invoiceDate DATE
AS
BEGIN
    SELECT
        COUNT(*) AS TotalInvoices,
        ISNULL(SUM(SubTotal), 0) AS TotalSubTotal,
        ISNULL(SUM(TotalGST), 0) AS TotalGSTCollected,
        ISNULL(SUM(DiscountAmount), 0) AS TotalDiscount,
        ISNULL(SUM(TotalAmount), 0) AS TotalSales
    FROM Invoices
    WHERE StoreId = @storeID
      AND CAST(InvoiceDate AS DATE) = @invoiceDate
      AND IsActive = 1;
END
GO
