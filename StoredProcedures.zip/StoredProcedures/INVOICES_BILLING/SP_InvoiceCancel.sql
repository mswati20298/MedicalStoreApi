-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to cancel an invoice and restore the stock back to respective batches
-- =====================================================
CREATE OR ALTER PROCEDURE SP_InvoiceCancel
    @invoiceID INT
AS
BEGIN
    DECLARE @batchID INT, @quantity INT;

    DECLARE cur CURSOR FOR
        SELECT BatchId, Quantity FROM InvoiceItems WHERE InvoiceId = @invoiceID;

    OPEN cur;
    FETCH NEXT FROM cur INTO @batchID, @quantity;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE Batches SET QuantityRemaining = QuantityRemaining + @quantity
        WHERE BatchId = @batchID;

        FETCH NEXT FROM cur INTO @batchID, @quantity;
    END

    CLOSE cur;
    DEALLOCATE cur;

    UPDATE Invoices SET IsActive = 0 WHERE InvoiceId = @invoiceID;
END
GO
