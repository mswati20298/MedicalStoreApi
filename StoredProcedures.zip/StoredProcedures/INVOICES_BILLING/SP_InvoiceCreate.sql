-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to create the invoice header record
-- =====================================================
CREATE OR ALTER PROCEDURE SP_InvoiceCreate
    @storeID INT,
    @invoiceNumber VARCHAR(50),
    @customerID INT = NULL,
    @paymentModeID INT,
    @subTotal DECIMAL(12,2),
    @totalGST DECIMAL(12,2),
    @discountAmount DECIMAL(12,2),
    @totalAmount DECIMAL(12,2),
    @createdBy INT
AS
BEGIN
    INSERT INTO Invoices (
        StoreId, InvoiceNumber, CustomerId, PaymentModeId,
        SubTotal, TotalGST, DiscountAmount, TotalAmount, CreatedBy, IsActive
    )
    VALUES (
        @storeID, @invoiceNumber, @customerID, @paymentModeID,
        @subTotal, @totalGST, @discountAmount, @totalAmount, @createdBy, 1
    );
    SELECT SCOPE_IDENTITY() AS InvoiceID;
END
GO
