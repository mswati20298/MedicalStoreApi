-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch invoices within a given date range
-- =====================================================
CREATE OR ALTER PROCEDURE SP_InvoiceGetByDateRange
    @storeID INT,
    @fromDate DATE,
    @toDate DATE
AS
BEGIN
    SELECT i.*, c.Name AS CustomerName, pm.ModeName
    FROM Invoices i
    LEFT JOIN Customers c ON i.CustomerId = c.CustomerId
    LEFT JOIN PaymentModes pm ON i.PaymentModeId = pm.PaymentModeId
    WHERE i.StoreId = @storeID
      AND CAST(i.InvoiceDate AS DATE) BETWEEN @fromDate AND @toDate
      AND i.IsActive = 1
    ORDER BY i.InvoiceDate DESC;
END
GO
