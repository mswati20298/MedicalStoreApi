-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to update a store's own details
-- (name, address, GSTIN, contact, logo, etc).
-- =====================================================
CREATE OR ALTER PROCEDURE SP_StoreUpdate
    @storeID INT,
    @storeName VARCHAR(150),
    @address VARCHAR(300) = NULL,
    @city VARCHAR(100) = NULL,
    @state VARCHAR(100) = NULL,
    @pincode VARCHAR(10) = NULL,
    @gstin VARCHAR(20) = NULL,
    @drugLicenseNumber VARCHAR(50) = NULL,
    @contactNumber VARCHAR(15) = NULL,
    @email VARCHAR(150) = NULL,
    @logoUrl VARCHAR(500) = NULL
AS
BEGIN
    UPDATE Stores
    SET StoreName = @storeName,
        Address = @address,
        City = @city,
        State = @state,
        Pincode = @pincode,
        GSTIN = @gstin,
        DrugLicenseNumber = @drugLicenseNumber,
        ContactNumber = @contactNumber,
        Email = @email,
        LogoUrl = @logoUrl
    WHERE StoreId = @storeID;
END
GO
