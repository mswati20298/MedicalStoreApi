-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new GST slab
-- =====================================================
CREATE OR ALTER PROCEDURE SP_GSTSlabInsert
    @percentage DECIMAL(5,2)
AS
BEGIN
    INSERT INTO GSTSlabs (Percentage, IsActive) VALUES (@percentage, 1);
    SELECT SCOPE_IDENTITY() AS GSTSlabID;
END
GO
