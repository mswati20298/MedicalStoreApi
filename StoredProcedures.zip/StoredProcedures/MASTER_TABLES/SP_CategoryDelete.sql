-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to soft-delete a category
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CategoryDelete
    @categoryID INT
AS
BEGIN
    UPDATE Categories SET IsActive = 0 WHERE CategoryId = @categoryID;
END
GO
