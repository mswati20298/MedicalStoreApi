-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch a store by its ID
-- =====================================================
CREATE OR ALTER PROCEDURE SP_StoreGetByID
    @storeID INT
AS
BEGIN
    SELECT * FROM Stores WHERE StoreId = @storeID AND IsActive = 1;
END
GO
