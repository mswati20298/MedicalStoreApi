-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to register a new store
-- =====================================================
CREATE OR ALTER PROCEDURE SP_StoreInsert
    @storeName VARCHAR(150),
    @address VARCHAR(300) = NULL,
    @city VARCHAR(100) = NULL,
    @state VARCHAR(100) = NULL,
    @pincode VARCHAR(10) = NULL,
    @gstin VARCHAR(20) = NULL,
    @drugLicenseNumber VARCHAR(50) = NULL,
    @contactNumber VARCHAR(15) = NULL,
    @email VARCHAR(150) = NULL
AS
BEGIN
    INSERT INTO Stores (StoreName, Address, City, State, Pincode, GSTIN, DrugLicenseNumber, ContactNumber, Email, IsActive)
    VALUES (@storeName, @address, @city, @state, @pincode, @gstin, @drugLicenseNumber, @contactNumber, @email, 1);
    SELECT SCOPE_IDENTITY() AS StoreID;
END
GO
