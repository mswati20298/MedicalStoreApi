-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active units
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UnitGetAll
AS
BEGIN
    SELECT * FROM Units WHERE IsActive = 1;
END
GO
