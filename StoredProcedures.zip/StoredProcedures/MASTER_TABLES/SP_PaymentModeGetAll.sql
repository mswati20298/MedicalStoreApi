-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active payment modes
-- =====================================================
CREATE OR ALTER PROCEDURE SP_PaymentModeGetAll
AS
BEGIN
    SELECT * FROM PaymentModes WHERE IsActive = 1;
END
GO
