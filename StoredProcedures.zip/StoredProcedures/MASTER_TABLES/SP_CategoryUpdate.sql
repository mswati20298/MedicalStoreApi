-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to update category details
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CategoryUpdate
    @categoryID INT,
    @categoryName VARCHAR(100),
    @parentCategoryID INT = NULL
AS
BEGIN
    UPDATE Categories
    SET CategoryName = @categoryName,
        ParentCategoryId = @parentCategoryID
    WHERE CategoryId = @categoryID;
END
GO
