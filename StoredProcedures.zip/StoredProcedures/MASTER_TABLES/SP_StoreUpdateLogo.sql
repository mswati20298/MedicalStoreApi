-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to update ONLY the LogoUrl of a store -
-- used right after a logo image is uploaded and saved to disk, so we
-- don't need to resend all other store fields just to save the logo path.
-- =====================================================
CREATE OR ALTER PROCEDURE SP_StoreUpdateLogo
    @storeID INT,
    @logoUrl VARCHAR(500)
AS
BEGIN
    UPDATE Stores
    SET LogoUrl = @logoUrl
    WHERE StoreId = @storeID;
END
GO
