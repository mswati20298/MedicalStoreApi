-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active stores (used for a
-- multi-store admin/switcher screen - e.g. listing "Shiva Medical",
-- "Health Care Pharmacy", etc. each with their own branding).
-- =====================================================
CREATE OR ALTER PROCEDURE SP_StoreGetAll
AS
BEGIN
    SELECT * FROM Stores WHERE IsActive = 1 ORDER BY StoreName;
END
GO
