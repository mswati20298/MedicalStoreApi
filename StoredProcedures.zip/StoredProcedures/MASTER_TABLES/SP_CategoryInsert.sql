-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new medicine category
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CategoryInsert
    @categoryName VARCHAR(100),
    @parentCategoryID INT = NULL
AS
BEGIN
    INSERT INTO Categories (CategoryName, ParentCategoryId, IsActive)
    VALUES (@categoryName, @parentCategoryID, 1);
    SELECT SCOPE_IDENTITY() AS CategoryID;
END
GO
