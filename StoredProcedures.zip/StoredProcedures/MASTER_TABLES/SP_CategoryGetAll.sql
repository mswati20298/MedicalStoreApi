-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active categories
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CategoryGetAll
AS
BEGIN
    SELECT * FROM Categories WHERE IsActive = 1;
END
GO
