-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Adds LogoUrl column to Stores table so each medical store
-- (e.g. "Shiva Medical", "Health Care Pharmacy") can have its own logo,
-- in addition to its own name/address/GSTIN which already existed.
-- Run this ONCE against your existing database.
-- =====================================================

IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'Stores' AND COLUMN_NAME = 'LogoUrl'
)
BEGIN
    ALTER TABLE Stores ADD LogoUrl VARCHAR(500) NULL;
END
GO
