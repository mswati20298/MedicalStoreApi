-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new unit (Strip, Bottle, etc.)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_UnitInsert
    @unitName VARCHAR(50)
AS
BEGIN
    INSERT INTO Units (UnitName, IsActive) VALUES (@unitName, 1);
    SELECT SCOPE_IDENTITY() AS UnitID;
END
GO
