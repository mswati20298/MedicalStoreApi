-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new payment mode
-- =====================================================
CREATE OR ALTER PROCEDURE SP_PaymentModeInsert
    @modeName VARCHAR(50)
AS
BEGIN
    INSERT INTO PaymentModes (ModeName, IsActive) VALUES (@modeName, 1);
    SELECT SCOPE_IDENTITY() AS PaymentModeID;
END
GO
