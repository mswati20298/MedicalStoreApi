-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active GST slabs
-- =====================================================
CREATE OR ALTER PROCEDURE SP_GSTSlabGetAll
AS
BEGIN
    SELECT * FROM GSTSlabs WHERE IsActive = 1;
END
GO
