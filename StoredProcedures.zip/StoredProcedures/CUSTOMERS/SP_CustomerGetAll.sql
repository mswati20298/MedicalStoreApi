-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active customers of a store
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerGetAll
    @storeID INT
AS
BEGIN
    SELECT * FROM Customers WHERE StoreId = @storeID AND IsActive = 1;
END
GO
