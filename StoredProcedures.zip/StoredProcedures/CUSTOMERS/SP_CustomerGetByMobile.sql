-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch a customer by mobile number
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerGetByMobile
    @storeID INT,
    @mobile VARCHAR(15)
AS
BEGIN
    SELECT * FROM Customers WHERE StoreId = @storeID AND Mobile = @mobile AND IsActive = 1;
END
GO
