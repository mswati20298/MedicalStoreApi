-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new customer, or return existing customer ID if mobile already exists
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerInsert
    @storeID INT,
    @name VARCHAR(150),
    @mobile VARCHAR(15),
    @address VARCHAR(300) = NULL
AS
BEGIN
    DECLARE @existingID INT = NULL;

    SELECT @existingID = CustomerId FROM Customers
    WHERE StoreId = @storeID AND Mobile = @mobile AND IsActive = 1;

    IF @existingID IS NULL
    BEGIN
        INSERT INTO Customers (StoreId, Name, Mobile, Address, IsActive)
        VALUES (@storeID, @name, @mobile, @address, 1);
        SELECT SCOPE_IDENTITY() AS CustomerID;
    END
    ELSE
    BEGIN
        SELECT @existingID AS CustomerID;
    END
END
GO
