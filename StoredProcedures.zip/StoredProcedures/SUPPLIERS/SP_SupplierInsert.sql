-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new supplier
-- =====================================================
CREATE OR ALTER PROCEDURE SP_SupplierInsert
    @storeID INT,
    @supplierName VARCHAR(150),
    @contactPerson VARCHAR(100) = NULL,
    @contactNumber VARCHAR(15) = NULL,
    @email VARCHAR(150) = NULL,
    @address VARCHAR(300) = NULL,
    @returnPolicyDays INT = 90,
    @gstin VARCHAR(20) = NULL
AS
BEGIN
    INSERT INTO Suppliers (StoreId, SupplierName, ContactPerson, ContactNumber, Email, Address, ReturnPolicyDays, GSTIN, IsActive)
    VALUES (@storeID, @supplierName, @contactPerson, @contactNumber, @email, @address, @returnPolicyDays, @gstin, 1);
    SELECT SCOPE_IDENTITY() AS SupplierID;
END
GO
