-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active suppliers of a store
-- =====================================================
CREATE OR ALTER PROCEDURE SP_SupplierGetAll
    @storeID INT
AS
BEGIN
    SELECT * FROM Suppliers WHERE StoreId = @storeID AND IsActive = 1;
END
GO
