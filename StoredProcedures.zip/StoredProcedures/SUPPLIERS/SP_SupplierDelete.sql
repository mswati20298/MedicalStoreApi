-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to soft-delete a supplier
-- =====================================================
CREATE OR ALTER PROCEDURE SP_SupplierDelete
    @supplierID INT
AS
BEGIN
    UPDATE Suppliers SET IsActive = 0 WHERE SupplierId = @supplierID;
END
GO
