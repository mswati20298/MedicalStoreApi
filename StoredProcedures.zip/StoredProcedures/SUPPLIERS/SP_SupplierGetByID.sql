-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch a supplier by its ID
-- =====================================================
CREATE OR ALTER PROCEDURE SP_SupplierGetByID
    @supplierID INT
AS
BEGIN
    SELECT * FROM Suppliers WHERE SupplierId = @supplierID AND IsActive = 1;
END
GO
