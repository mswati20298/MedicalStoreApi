-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to update supplier details
-- =====================================================
CREATE OR ALTER PROCEDURE SP_SupplierUpdate
    @supplierID INT,
    @supplierName VARCHAR(150),
    @contactPerson VARCHAR(100) = NULL,
    @contactNumber VARCHAR(15) = NULL,
    @email VARCHAR(150) = NULL,
    @address VARCHAR(300) = NULL,
    @returnPolicyDays INT = 90,
    @gstin VARCHAR(20) = NULL
AS
BEGIN
    UPDATE Suppliers
    SET SupplierName = @supplierName,
        ContactPerson = @contactPerson,
        ContactNumber = @contactNumber,
        Email = @email,
        Address = @address,
        ReturnPolicyDays = @returnPolicyDays,
        GSTIN = @gstin
    WHERE SupplierId = @supplierID;
END
GO
