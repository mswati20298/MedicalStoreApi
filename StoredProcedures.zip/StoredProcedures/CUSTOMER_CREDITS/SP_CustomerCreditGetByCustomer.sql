-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch credit history of a specific customer
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerCreditGetByCustomer
    @customerID INT
AS
BEGIN
    SELECT * FROM CustomerCredits
    WHERE CustomerId = @customerID
    ORDER BY CreatedDate DESC;
END
GO
