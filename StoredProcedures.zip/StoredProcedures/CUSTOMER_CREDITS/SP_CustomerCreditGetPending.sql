-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all pending/partially paid credits of a store
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerCreditGetPending
    @storeID INT
AS
BEGIN
    SELECT cc.*, c.Name AS CustomerName, c.Mobile
    FROM CustomerCredits cc
    JOIN Customers c ON cc.CustomerId = c.CustomerId
    WHERE cc.StoreId = @storeID
      AND cc.Status IN ('Pending', 'PartiallyPaid')
    ORDER BY cc.DueDate ASC;
END
GO
