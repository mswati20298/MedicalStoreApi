-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to record a credit payment and auto-update credit status
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerCreditAddPayment
    @creditID INT,
    @amountPaid DECIMAL(12,2),
    @paymentModeID INT
AS
BEGIN
    DECLARE @totalAmount DECIMAL(12,2), @alreadyPaid DECIMAL(12,2), @newPaidTotal DECIMAL(12,2);

    INSERT INTO CreditPayments (CreditId, AmountPaid, PaymentModeId)
    VALUES (@creditID, @amountPaid, @paymentModeID);

    SELECT @totalAmount = Amount, @alreadyPaid = AmountPaid
    FROM CustomerCredits WHERE CreditId = @creditID;

    SET @newPaidTotal = @alreadyPaid + @amountPaid;

    UPDATE CustomerCredits
    SET AmountPaid = @newPaidTotal,
        Status = CASE
            WHEN @newPaidTotal >= @totalAmount THEN 'Paid'
            WHEN @newPaidTotal > 0 THEN 'PartiallyPaid'
            ELSE 'Pending'
        END
    WHERE CreditId = @creditID;

    SELECT 1 AS Success;
END
GO
