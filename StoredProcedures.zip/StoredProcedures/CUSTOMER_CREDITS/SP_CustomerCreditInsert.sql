-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to record a new customer credit (udhaar) entry
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerCreditInsert
    @storeID INT,
    @customerID INT,
    @invoiceID INT = NULL,
    @amount DECIMAL(12,2),
    @dueDate DATE = NULL
AS
BEGIN
    INSERT INTO CustomerCredits (StoreId, CustomerId, InvoiceId, Amount, AmountPaid, DueDate, Status)
    VALUES (@storeID, @customerID, @invoiceID, @amount, 0, @dueDate, 'Pending');
    SELECT SCOPE_IDENTITY() AS CreditID;
END
GO
