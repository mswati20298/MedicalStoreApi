-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch a single credit record by ID - used
-- by CustomerCreditsService to verify the credit belongs to the caller's
-- own store before allowing a payment to be recorded against it.
-- =====================================================
CREATE OR ALTER PROCEDURE SP_CustomerCreditGetByID
    @creditID INT
AS
BEGIN
    SELECT cc.*, c.Name AS CustomerName, c.Mobile
    FROM CustomerCredits cc
    JOIN Customers c ON cc.CustomerId = c.CustomerId
    WHERE cc.CreditId = @creditID;
END
GO
