-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all active medicines of a store
-- =====================================================
CREATE OR ALTER PROCEDURE SP_MedicineGetAll
    @storeID INT
AS
BEGIN
    SELECT m.*, c.CategoryName, u.UnitName, g.Percentage AS GSTPercentage
    FROM Medicines m
    LEFT JOIN Categories c ON m.CategoryId = c.CategoryId
    LEFT JOIN Units u ON m.UnitId = u.UnitId
    LEFT JOIN GSTSlabs g ON m.GSTSlabId = g.GSTSlabId
    WHERE m.StoreId = @storeID AND m.IsActive = 1
    ORDER BY m.Name;
END
GO
