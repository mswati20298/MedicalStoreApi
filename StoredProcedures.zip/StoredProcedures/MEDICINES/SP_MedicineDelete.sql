-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to soft-delete a medicine
-- =====================================================
CREATE OR ALTER PROCEDURE SP_MedicineDelete
    @medicineID INT
AS
BEGIN
    UPDATE Medicines SET IsActive = 0 WHERE MedicineId = @medicineID;
END
GO
