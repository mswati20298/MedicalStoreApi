-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new medicine master record
-- =====================================================
CREATE OR ALTER PROCEDURE SP_MedicineInsert
    @storeID INT,
    @name VARCHAR(200),
    @composition VARCHAR(300) = NULL,
    @manufacturer VARCHAR(150) = NULL,
    @categoryID INT = NULL,
    @unitID INT = NULL,
    @gstSlabID INT = NULL,
    @hsnCode VARCHAR(20) = NULL,
    @prescriptionRequired BIT = 0,
    @reorderPoint INT = 0,
    @maxStockLevel INT = 0
AS
BEGIN
    INSERT INTO Medicines (
        StoreId, Name, Composition, Manufacturer, CategoryId, UnitId,
        GSTSlabId, HSNCode, PrescriptionRequired, ReorderPoint, MaxStockLevel, IsActive
    )
    VALUES (
        @storeID, @name, @composition, @manufacturer, @categoryID, @unitID,
        @gstSlabID, @hsnCode, @prescriptionRequired, @reorderPoint, @maxStockLevel, 1
    );
    SELECT SCOPE_IDENTITY() AS MedicineID;
END
GO
