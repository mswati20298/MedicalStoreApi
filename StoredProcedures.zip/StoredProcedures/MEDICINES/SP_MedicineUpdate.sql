-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to update medicine master details
-- =====================================================
CREATE OR ALTER PROCEDURE SP_MedicineUpdate
    @medicineID INT,
    @name VARCHAR(200),
    @composition VARCHAR(300) = NULL,
    @manufacturer VARCHAR(150) = NULL,
    @categoryID INT = NULL,
    @unitID INT = NULL,
    @gstSlabID INT = NULL,
    @hsnCode VARCHAR(20) = NULL,
    @prescriptionRequired BIT = 0,
    @reorderPoint INT = 0,
    @maxStockLevel INT = 0
AS
BEGIN
    UPDATE Medicines
    SET Name = @name,
        Composition = @composition,
        Manufacturer = @manufacturer,
        CategoryId = @categoryID,
        UnitId = @unitID,
        GSTSlabId = @gstSlabID,
        HSNCode = @hsnCode,
        PrescriptionRequired = @prescriptionRequired,
        ReorderPoint = @reorderPoint,
        MaxStockLevel = @maxStockLevel
    WHERE MedicineId = @medicineID;
END
GO
