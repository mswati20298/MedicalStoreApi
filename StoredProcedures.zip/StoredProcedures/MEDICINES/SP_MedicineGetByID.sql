-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch a medicine by its ID (with category/unit/GST info)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_MedicineGetByID
    @medicineID INT
AS
BEGIN
    SELECT m.*, c.CategoryName, u.UnitName, g.Percentage AS GSTPercentage
    FROM Medicines m
    LEFT JOIN Categories c ON m.CategoryId = c.CategoryId
    LEFT JOIN Units u ON m.UnitId = u.UnitId
    LEFT JOIN GSTSlabs g ON m.GSTSlabId = g.GSTSlabId
    WHERE m.MedicineId = @medicineID AND m.IsActive = 1;
END
GO
