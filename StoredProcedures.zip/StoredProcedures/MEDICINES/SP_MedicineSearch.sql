-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to search medicines by name (used for billing screen autocomplete)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_MedicineSearch
    @storeID INT,
    @searchTerm VARCHAR(200)
AS
BEGIN
    SELECT TOP 20 m.MedicineId, m.Name, m.Composition, u.UnitName, g.Percentage AS GSTPercentage
    FROM Medicines m
    LEFT JOIN Units u ON m.UnitId = u.UnitId
    LEFT JOIN GSTSlabs g ON m.GSTSlabId = g.GSTSlabId
    WHERE m.StoreId = @storeID
      AND m.IsActive = 1
      AND m.Name LIKE @searchTerm + '%';
END
GO
