-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to insert a new stock batch for a medicine
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchInsert
    @storeID INT,
    @medicineID INT,
    @supplierID INT = NULL,
    @batchNumber VARCHAR(100),
    @expiryDate DATE,
    @manufactureDate DATE = NULL,
    @quantityReceived INT,
    @purchasePrice DECIMAL(10,2),
    @mrp DECIMAL(10,2),
    @dateReceived DATE
AS
BEGIN
    INSERT INTO Batches (
        StoreId, MedicineId, SupplierId, BatchNumber, ExpiryDate, ManufactureDate,
        QuantityReceived, QuantityRemaining, PurchasePrice, MRP, DateReceived, IsActive
    )
    VALUES (
        @storeID, @medicineID, @supplierID, @batchNumber, @expiryDate, @manufactureDate,
        @quantityReceived, @quantityReceived, @purchasePrice, @mrp, @dateReceived, 1
    );
    SELECT SCOPE_IDENTITY() AS BatchID;
END
GO
