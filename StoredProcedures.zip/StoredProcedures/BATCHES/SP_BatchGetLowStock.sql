-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to identify medicines whose current stock has fallen below reorder point
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchGetLowStock
    @storeID INT
AS
BEGIN
    SELECT
        m.MedicineId, m.Name, m.ReorderPoint, m.MaxStockLevel,
        ISNULL(SUM(b.QuantityRemaining), 0) AS CurrentStock
    FROM Medicines m
    LEFT JOIN Batches b ON m.MedicineId = b.MedicineId AND b.IsActive = 1
    WHERE m.StoreId = @storeID AND m.IsActive = 1
    GROUP BY m.MedicineId, m.Name, m.ReorderPoint, m.MaxStockLevel
    HAVING ISNULL(SUM(b.QuantityRemaining), 0) <= m.ReorderPoint;
END
GO
