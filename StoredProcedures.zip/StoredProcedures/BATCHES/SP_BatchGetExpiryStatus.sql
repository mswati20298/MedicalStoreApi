-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to get Red/Yellow/Green expiry status of all batches in a store
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchGetExpiryStatus
    @storeID INT,
    @redDays INT,      -- e.g. 30
    @yellowDays INT    -- e.g. 90
AS
BEGIN
    SELECT
        b.BatchId, b.BatchNumber, b.ExpiryDate, b.QuantityRemaining,
        m.Name AS MedicineName, m.MedicineId,
        s.SupplierName, s.ReturnPolicyDays,
        DATEDIFF(DAY, GETDATE(), b.ExpiryDate) AS DaysToExpiry,
        CASE
            WHEN DATEDIFF(DAY, GETDATE(), b.ExpiryDate) <= @redDays THEN 'RED'
            WHEN DATEDIFF(DAY, GETDATE(), b.ExpiryDate) <= @yellowDays THEN 'YELLOW'
            ELSE 'GREEN'
        END AS ExpiryStatus
    FROM Batches b
    JOIN Medicines m ON b.MedicineId = m.MedicineId
    LEFT JOIN Suppliers s ON b.SupplierId = s.SupplierId
    WHERE b.StoreId = @storeID
      AND b.IsActive = 1
      AND b.QuantityRemaining > 0
    ORDER BY b.ExpiryDate ASC;
END
GO
