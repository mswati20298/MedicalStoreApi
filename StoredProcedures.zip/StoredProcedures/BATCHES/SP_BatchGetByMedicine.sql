-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch all batches of a medicine sorted by expiry (FEFO order)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchGetByMedicine
    @medicineID INT
AS
BEGIN
    -- FEFO order: expiry ke hisaab se sorted (jo pehle expire hoga wo upar)
    SELECT b.*, s.SupplierName
    FROM Batches b
    LEFT JOIN Suppliers s ON b.SupplierId = s.SupplierId
    WHERE b.MedicineId = @medicineID
      AND b.IsActive = 1
      AND b.QuantityRemaining > 0
    ORDER BY b.ExpiryDate ASC;
END
GO
