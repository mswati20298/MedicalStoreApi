-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to reduce batch stock quantity (used internally during billing)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchReduceStock
    @batchID INT,
    @quantity INT
AS
BEGIN
    UPDATE Batches
    SET QuantityRemaining = QuantityRemaining - @quantity
    WHERE BatchId = @batchID AND QuantityRemaining >= @quantity;
END
GO
