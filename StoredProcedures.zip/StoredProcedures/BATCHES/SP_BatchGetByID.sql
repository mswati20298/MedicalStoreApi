-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch a single batch by its ID - used by
-- BatchesService to verify the batch belongs to the caller's own store
-- before allowing a delete.
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchGetByID
    @batchID INT
AS
BEGIN
    SELECT b.*, m.Name AS MedicineName, s.SupplierName
    FROM Batches b
    JOIN Medicines m ON b.MedicineId = m.MedicineId
    LEFT JOIN Suppliers s ON b.SupplierId = s.SupplierId
    WHERE b.BatchId = @batchID AND b.IsActive = 1;
END
GO
