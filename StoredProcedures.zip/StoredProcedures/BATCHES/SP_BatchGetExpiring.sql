-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to fetch batches expiring within given number of days (dashboard alert)
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchGetExpiring
    @storeID INT,
    @days INT
AS
BEGIN
    SELECT b.*, m.Name AS MedicineName, DATEDIFF(DAY, GETDATE(), b.ExpiryDate) AS DaysToExpiry
    FROM Batches b
    JOIN Medicines m ON b.MedicineId = m.MedicineId
    WHERE b.StoreId = @storeID
      AND b.IsActive = 1
      AND b.QuantityRemaining > 0
      AND DATEDIFF(DAY, GETDATE(), b.ExpiryDate) <= @days
    ORDER BY b.ExpiryDate ASC;
END
GO
