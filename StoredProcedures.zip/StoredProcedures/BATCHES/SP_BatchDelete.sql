-- =====================================================
-- Author: Mahesh Kumar
-- Date: 26/07/2026
-- Description: Created this SP to soft-delete a batch
-- =====================================================
CREATE OR ALTER PROCEDURE SP_BatchDelete
    @batchID INT
AS
BEGIN
    UPDATE Batches SET IsActive = 0 WHERE BatchId = @batchID;
END
GO
